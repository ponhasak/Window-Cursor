ENTIS CURSOR SET
(c) http://www.entis-design.com

INSTALLATION ON MICROSOFT(R) WINDOWS(R) XP AND VISTA
Whole cursor set can be installed by right clicking on the "install.inf" file
and selecting "Install". Then simply open Mouse control panel, tab Cursors, 
select Entis Cursors and click Apply.

Or you can apply every single one cursor manually in forementioned control
panel (by browsing for the given cursor file).

You can possibly use this cursors on Windows 95, 98, NT and 2000, but they
may look very odd.

INSTALLATION ON LINUX AND OTHER SYSTEM
Installation on different systems may vary. For Linux, there is a "make.sh" 
build file prepared as well as compiled files (in subdirectory cursors).

For the other systems, you can use provided source PNG files to build up
the cursors (see licensing for more info) on your own.

LICENSING
This cursor set may be used and distributed under following conditions:
1. You can use this cursor set (or every single one from the set) for 
   personal use only. 
2. You may not modify the cursors without prior permission from author.
3. Redistribution (either individually or in some collection) is possible
   only without any profit. Please note (by e-mail) author about further
	 redistribution.
4. The cursor set must always stay intact, containing copyrights and licensing 
   informations.
5. If you use provided source PNG files to build up the cursors for
	 some platform, you have to share them under the same licensing conditions
	 as holds for this cursor set.
6. This cursor set is provided without any warranty, liability or responsibility.

For any other situation, permission from author is required. Author can be 
contacted at any time at info@entis-design.com.

Microsoft, Windows and Linux may be registered trademarks of their respective 
owners.
